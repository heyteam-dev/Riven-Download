var riven = 0;
var rivenPerClick = 1;
var morerivPrice = 50;
// 100000
var messages = ["Dev: BM_X_Coder#4505", "Design: Face_Ender#8905", "Design: Lol Raf#6049"];

document.addEventListener('contextmenu', event => event.preventDefault());


document.getElementById("riven").innerHTML = "Riv: " + riven;

function clickriv(){
  riven = riven + rivenPerClick;
  document.getElementById("riven").innerHTML = "Riv: " + riven;
}

function doConfetti(duration){
  confetti.start();
  setTimeout(function(){confetti.stop()}, duration)
}

function hideMenu(){
  document.getElementById("menu").style.visibility = "hidden";
  document.getElementById("continue").style.visibility = "hidden";
  document.getElementById("menuShadow").style.visibility = "hidden";
  document.body.style.overflow = "auto";
  document.getElementById("message").innerHTML = messages[Math.floor(Math.random() * messages.length)];
  audio.play();
  setInterval(function(){
  document.getElementById("message").innerHTML = messages[Math.floor(Math.random() * messages.length)];
}, 10000);
}

function moreriv(){
  if(riven >= morerivPrice){
    riven = riven - morerivPrice;
    morerivPrice = Math.round(morerivPrice + (morerivPrice / 15));
    rivenPerClick++;
    document.getElementById("moreriv").innerHTML = "mehr riv: $" + rivenPerClick + "<br>riv Per Click: " + rivenPerClick;
    document.getElementById("riven").innerHTML = "riv: " + riven
    if(rivenPerClick == 2){
      doConfetti(2000);
    }
  }
}

function speichern() {
 var key = "2355:4564:3456:2453:3656:3454:4623:4532:4634";
 var data = document.getElementById('riven').value;
 window.localStorage.setItem(key, riven);
}

function lesen() {
 var key = "2355:4564:3456:2453:3656:3454:4623:4532:4634";
 document.getElementById('riven').value = window.localStorage.getItem(key);
}








